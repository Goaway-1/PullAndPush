// Fill out your copyright notice in the Description page of Project Settings.

#include "PullAndPush.h"
#include "Modules/ModuleManager.h"

DEFINE_LOG_CATEGORY(PullAndPush);
IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, PullAndPush, "PullAndPush" );
