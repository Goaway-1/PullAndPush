// Fill out your copyright notice in the Description page of Project Settings.


#include "Interface/CharacterInterActionHandler.h"

// Add default functionality here for any ICollisionActionHandler functions that are not pure virtual.
